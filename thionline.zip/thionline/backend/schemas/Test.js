var mongoose = require("mongoose");
var Test = new mongoose.Schema({

})
module.exports = Test;
