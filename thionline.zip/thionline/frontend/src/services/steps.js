export const steps = [
    {
      title: 'Chi tiết'
    },
    {
      title: 'Chọn câu hỏi'
    },
    {
      title: 'Hoàn thành'
    }
];